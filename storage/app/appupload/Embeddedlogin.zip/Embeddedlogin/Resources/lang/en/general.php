<?php

return [

    'name'              => 'Embeddedlogin',
    'description'       => 'This is my awesome module',

];